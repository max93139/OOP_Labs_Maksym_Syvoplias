var dir_142a6ba5034caf9b94510091e90c1d58 =
[
    [ ".NETCoreApp,Version=v10.0.AssemblyAttributes.cs", "_8_n_e_t_core_app_00_version_0av10_80_8_assembly_attributes_8cs.html", null ],
    [ "Lab3.AssemblyInfo.cs", "_lab3_8_assembly_info_8cs.html", null ],
    [ "Lab3.GlobalUsings.g.cs", "_lab3_8_global_usings_8g_8cs.html", null ]
];