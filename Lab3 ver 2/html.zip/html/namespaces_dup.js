var namespaces_dup =
[
    [ "Lab3", "namespace_lab3.html", "namespace_lab3" ]
];