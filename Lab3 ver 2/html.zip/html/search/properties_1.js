var searchData=
[
  ['data_0',['Data',['../class_lab3_1_1_service.html#a08133412a8cb2de3a0f59ebe70c09879',1,'Lab3::Service']]],
  ['disciplines_1',['Disciplines',['../class_lab3_1_1_department.html#a6dc3614d7f949032abe52ed2b4a7a516',1,'Lab3::Department']]]
];
