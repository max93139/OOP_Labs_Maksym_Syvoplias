var indexSectionsWithContent =
{
  0: ".abcdefghlmnoprsvw",
  1: "dps",
  2: "l",
  3: ".dlps",
  4: "abcdfghmprsvw",
  5: "adefgmnorsw",
  6: "adefgmnorsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Properties"
};

