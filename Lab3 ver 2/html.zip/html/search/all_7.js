var searchData=
[
  ['getstudentbynumber_0',['GetStudentByNumber',['../class_lab3_1_1_department.html#ac44e8023a102a84998354e397fee00da',1,'Lab3::Department']]],
  ['grades_1',['Grades',['../class_lab3_1_1_student.html#a5c770f15569b9100f2d9c9ec06e85dfb',1,'Lab3::Student']]],
  ['grades_2',['grades',['../class_lab3_1_1_student.html#af8c5dbe0088bbdca7387c5168a3df52b',1,'Lab3::Student']]]
];
