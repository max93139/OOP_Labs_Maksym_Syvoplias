var searchData=
[
  ['maxstudents_0',['maxStudents',['../class_lab3_1_1_department.html#a0f10615203cf074d1318d5c366af7f56',1,'Lab3::Department']]]
];
