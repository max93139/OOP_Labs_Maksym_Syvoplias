var searchData=
[
  ['viewgrades_0',['ViewGrades',['../class_lab3_1_1_student.html#a5766ec932718b99f5a81041a3f0d1c10',1,'Lab3::Student']]]
];
