var searchData=
[
  ['studentcount_0',['StudentCount',['../class_lab3_1_1_department.html#abe2febc4b35935e8a690c8de3c60501c',1,'Lab3::Department']]],
  ['studentnumber_1',['StudentNumber',['../class_lab3_1_1_student.html#af54e482310ee6a5541b4fefcf5abc548',1,'Lab3::Student']]],
  ['students_2',['Students',['../class_lab3_1_1_department.html#adf338da93a7b404b63efe59ce834888e',1,'Lab3::Department']]]
];
