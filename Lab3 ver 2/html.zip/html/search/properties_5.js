var searchData=
[
  ['maxstudents_0',['MaxStudents',['../class_lab3_1_1_department.html#ac7b8c4bec265380c43c145c0f06534c1',1,'Lab3::Department']]]
];
