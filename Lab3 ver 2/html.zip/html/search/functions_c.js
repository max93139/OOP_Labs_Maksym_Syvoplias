var searchData=
[
  ['writetoconsole_0',['WriteToConsole',['../class_lab3_1_1_service.html#afd1ce9199e69ad7d536b69434e71a72a',1,'Lab3::Service']]],
  ['writetofile_1',['WriteToFile',['../class_lab3_1_1_service.html#ab29833091878d190d756447d4050fdbb',1,'Lab3::Service']]]
];
