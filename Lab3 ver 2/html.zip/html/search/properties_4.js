var searchData=
[
  ['grades_0',['Grades',['../class_lab3_1_1_student.html#a5c770f15569b9100f2d9c9ec06e85dfb',1,'Lab3::Student']]]
];
