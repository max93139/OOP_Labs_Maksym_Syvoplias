var searchData=
[
  ['educationprogram_0',['EducationProgram',['../class_lab3_1_1_department.html#a93aafc5f5e71ce057ae4ba9d73da1b10',1,'Lab3.Department.EducationProgram'],['../class_lab3_1_1_student.html#a768b0aa09860e31784ac995fb22ebe55',1,'Lab3.Student.EducationProgram']]],
  ['educationprogram_1',['educationProgram',['../class_lab3_1_1_department.html#a75faf7f2e00b9f293f7f8292a4f6ef16',1,'Lab3.Department.educationProgram'],['../class_lab3_1_1_student.html#a437c07d0a9067f644e122619ea0d2c06',1,'Lab3.Student.educationProgram']]]
];
