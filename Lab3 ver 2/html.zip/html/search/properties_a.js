var searchData=
[
  ['workloadlevel_0',['WorkloadLevel',['../class_lab3_1_1_student.html#af3678a23697997bbc49da8f6a22d4575',1,'Lab3::Student']]]
];
