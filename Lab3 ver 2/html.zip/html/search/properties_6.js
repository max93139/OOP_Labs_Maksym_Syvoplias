var searchData=
[
  ['name_0',['Name',['../class_lab3_1_1_department.html#a8ef3d634449357bfe52241868444e9fc',1,'Lab3.Department.Name'],['../class_lab3_1_1_student.html#a073e02e88eab780cedd6927525904843',1,'Lab3.Student.Name']]]
];
