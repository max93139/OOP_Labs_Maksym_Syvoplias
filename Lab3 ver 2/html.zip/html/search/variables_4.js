var searchData=
[
  ['grades_0',['grades',['../class_lab3_1_1_student.html#af8c5dbe0088bbdca7387c5168a3df52b',1,'Lab3::Student']]]
];
