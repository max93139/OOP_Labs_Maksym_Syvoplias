var searchData=
[
  ['calculaterating_0',['CalculateRating',['../class_lab3_1_1_student.html#a20a192f3e768c0824ec5a8dbeaac3c20',1,'Lab3::Student']]],
  ['changespecialty_1',['ChangeSpecialty',['../class_lab3_1_1_student.html#aa87488f48a80be8f8338b08675462b2e',1,'Lab3::Student']]],
  ['changeworkload_2',['ChangeWorkload',['../class_lab3_1_1_student.html#a347a713e2cb899d364fbe7ca2d6e0588',1,'Lab3::Student']]]
];
