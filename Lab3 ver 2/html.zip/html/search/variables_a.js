var searchData=
[
  ['workloadlevel_0',['workloadLevel',['../class_lab3_1_1_student.html#a00dca19ad2ff836d5159ada1da9877ac',1,'Lab3::Student']]]
];
