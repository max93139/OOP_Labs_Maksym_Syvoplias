var searchData=
[
  ['admissionreason_0',['AdmissionReason',['../class_lab3_1_1_student.html#ae6f6a240f384ff668cc969b931ca1462',1,'Lab3::Student']]]
];
