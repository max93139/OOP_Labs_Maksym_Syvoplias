var searchData=
[
  ['educationprogram_0',['educationProgram',['../class_lab3_1_1_department.html#a75faf7f2e00b9f293f7f8292a4f6ef16',1,'Lab3.Department.educationProgram'],['../class_lab3_1_1_student.html#a437c07d0a9067f644e122619ea0d2c06',1,'Lab3.Student.educationProgram']]]
];
