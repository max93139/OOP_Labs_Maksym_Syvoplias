var searchData=
[
  ['admissionreason_0',['admissionReason',['../class_lab3_1_1_student.html#ad58a00297928dd3e8ca1acd6ed76bf06',1,'Lab3::Student']]]
];
