var searchData=
[
  ['getstudentbynumber_0',['GetStudentByNumber',['../class_lab3_1_1_department.html#ac44e8023a102a84998354e397fee00da',1,'Lab3::Department']]]
];
