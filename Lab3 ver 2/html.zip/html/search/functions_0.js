var searchData=
[
  ['adddiscipline_0',['AddDiscipline',['../class_lab3_1_1_department.html#a7216dfb1a265cdb376838f3465f43bbd',1,'Lab3::Department']]],
  ['adddisciplinesduringcreation_1',['AddDisciplinesDuringCreation',['../class_lab3_1_1_service.html#a20585ced569956f5ac9ab05399231c6f',1,'Lab3::Service']]],
  ['addgrade_2',['AddGrade',['../class_lab3_1_1_student.html#a0cbdabc3db53d978d3804601fd483352',1,'Lab3::Student']]],
  ['addstudent_3',['AddStudent',['../class_lab3_1_1_department.html#a29f12e369af9e0187459cfd921db76fe',1,'Lab3::Department']]]
];
