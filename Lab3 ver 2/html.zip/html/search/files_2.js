var searchData=
[
  ['lab3_2eassemblyinfo_2ecs_0',['Lab3.AssemblyInfo.cs',['../_lab3_8_assembly_info_8cs.html',1,'']]],
  ['lab3_2eglobalusings_2eg_2ecs_1',['Lab3.GlobalUsings.g.cs',['../_lab3_8_global_usings_8g_8cs.html',1,'']]]
];
