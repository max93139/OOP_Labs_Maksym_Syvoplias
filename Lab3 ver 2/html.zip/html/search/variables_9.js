var searchData=
[
  ['studentcount_0',['studentCount',['../class_lab3_1_1_department.html#a20c7bc5a7da24c3bf28364b157b79384',1,'Lab3::Department']]],
  ['studentnumber_1',['studentNumber',['../class_lab3_1_1_student.html#a7701c4b601b61d87fca619c4d2531c56',1,'Lab3::Student']]],
  ['students_2',['students',['../class_lab3_1_1_department.html#a05de6e4b71133436adc1659a67c60548',1,'Lab3::Department']]]
];
