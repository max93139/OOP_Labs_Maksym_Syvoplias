var searchData=
[
  ['department_0',['Department',['../class_lab3_1_1_department.html#a4ced775bf7afe1ce77c404cb4ea9793a',1,'Lab3.Department.Department()'],['../class_lab3_1_1_department.html#a584c53fb0be242d4e31da5ef079f2d9b',1,'Lab3.Department.Department(string name, int studentCount, string educationProgram, List&lt; string &gt; disciplines, int maxStudents)']]]
];
