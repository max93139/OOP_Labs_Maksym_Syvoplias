var searchData=
[
  ['data_0',['data',['../class_lab3_1_1_service.html#a61ab3393bec5247a2bef78c1c4b1315d',1,'Lab3::Service']]],
  ['disciplines_1',['disciplines',['../class_lab3_1_1_department.html#a6f7a3793734c49d07af34f7fcef22fd6',1,'Lab3::Department']]]
];
