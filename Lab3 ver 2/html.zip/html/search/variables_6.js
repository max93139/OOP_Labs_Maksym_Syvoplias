var searchData=
[
  ['name_0',['name',['../class_lab3_1_1_department.html#ac18826cfd79416bb7781f9f5a4500cd0',1,'Lab3.Department.name'],['../class_lab3_1_1_student.html#a167a97c23b125b054893cef6b271580b',1,'Lab3.Student.name']]]
];
