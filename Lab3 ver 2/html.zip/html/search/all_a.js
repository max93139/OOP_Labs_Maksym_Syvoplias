var searchData=
[
  ['main_0',['Main',['../class_lab3_1_1_program.html#a31d74f9e75575f20ddf58669b7e06f3e',1,'Lab3::Program']]],
  ['maxstudents_1',['MaxStudents',['../class_lab3_1_1_department.html#ac7b8c4bec265380c43c145c0f06534c1',1,'Lab3::Department']]],
  ['maxstudents_2',['maxStudents',['../class_lab3_1_1_department.html#a0f10615203cf074d1318d5c366af7f56',1,'Lab3::Department']]]
];
