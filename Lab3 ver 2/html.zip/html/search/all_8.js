var searchData=
[
  ['handleadddiscipline_0',['HandleAddDiscipline',['../class_lab3_1_1_service.html#a55bf5a78fb4298a792f93d27f3ae6b45',1,'Lab3::Service']]],
  ['handleaddgrade_1',['HandleAddGrade',['../class_lab3_1_1_service.html#a224bbbbc5b4d06ca3d09d9a9156d55e1',1,'Lab3::Service']]],
  ['handleaddstudent_2',['HandleAddStudent',['../class_lab3_1_1_service.html#a8f53d0a95971d3060b6b38aba9eda848',1,'Lab3::Service']]],
  ['handlecalculaterating_3',['HandleCalculateRating',['../class_lab3_1_1_service.html#a0a8fb230489f002cd83eeae6f61ed82b',1,'Lab3::Service']]],
  ['handlechangespecialty_4',['HandleChangeSpecialty',['../class_lab3_1_1_service.html#a3fe644c4dbbc8b7522657835442db0d8',1,'Lab3::Service']]],
  ['handlechangeworkload_5',['HandleChangeWorkload',['../class_lab3_1_1_service.html#a95228cb36d99d0fe398aa72e6836434e',1,'Lab3::Service']]],
  ['handlecreatedepartment_6',['HandleCreateDepartment',['../class_lab3_1_1_service.html#a5570d6d25244344661f8e3b23889c0a0',1,'Lab3::Service']]],
  ['handlereaddata_7',['HandleReadData',['../class_lab3_1_1_service.html#a0ae9a38b9f5d0b00adef0d76ddbc0dd1',1,'Lab3::Service']]],
  ['handleremovediscipline_8',['HandleRemoveDiscipline',['../class_lab3_1_1_service.html#a4ced23a7e264f729bc8b69c105b6a2ae',1,'Lab3::Service']]],
  ['handleremovestudent_9',['HandleRemoveStudent',['../class_lab3_1_1_service.html#a07178d4f49dcbbde2e97c80f2d968e94',1,'Lab3::Service']]],
  ['handlesavedata_10',['HandleSaveData',['../class_lab3_1_1_service.html#aedb4e022e7f31f3b9dc06c38f0ddbf3e',1,'Lab3::Service']]],
  ['handleviewgrades_11',['HandleViewGrades',['../class_lab3_1_1_service.html#ac38f0f0491fa0fe67d6a3de64bcecb98',1,'Lab3::Service']]]
];
