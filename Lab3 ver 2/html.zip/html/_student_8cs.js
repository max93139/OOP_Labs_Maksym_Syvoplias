var _student_8cs =
[
    [ "Lab3.Student", "class_lab3_1_1_student.html", "class_lab3_1_1_student" ]
];