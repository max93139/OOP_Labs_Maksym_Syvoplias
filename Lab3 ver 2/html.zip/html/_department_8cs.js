var _department_8cs =
[
    [ "Lab3.Department", "class_lab3_1_1_department.html", "class_lab3_1_1_department" ]
];