var class_lab3_1_1_student =
[
    [ "Student", "class_lab3_1_1_student.html#ad0b39f11becfcecd4a6329edfada14c5", null ],
    [ "Student", "class_lab3_1_1_student.html#a1994129997a340870a8e86b04fbde49f", null ],
    [ "AddGrade", "class_lab3_1_1_student.html#a0cbdabc3db53d978d3804601fd483352", null ],
    [ "CalculateRating", "class_lab3_1_1_student.html#a20a192f3e768c0824ec5a8dbeaac3c20", null ],
    [ "ChangeSpecialty", "class_lab3_1_1_student.html#aa87488f48a80be8f8338b08675462b2e", null ],
    [ "ChangeWorkload", "class_lab3_1_1_student.html#a347a713e2cb899d364fbe7ca2d6e0588", null ],
    [ "ViewGrades", "class_lab3_1_1_student.html#a5766ec932718b99f5a81041a3f0d1c10", null ],
    [ "admissionReason", "class_lab3_1_1_student.html#ad58a00297928dd3e8ca1acd6ed76bf06", null ],
    [ "educationProgram", "class_lab3_1_1_student.html#a437c07d0a9067f644e122619ea0d2c06", null ],
    [ "grades", "class_lab3_1_1_student.html#af8c5dbe0088bbdca7387c5168a3df52b", null ],
    [ "name", "class_lab3_1_1_student.html#a167a97c23b125b054893cef6b271580b", null ],
    [ "rating", "class_lab3_1_1_student.html#ada7869e3bc4b5ea6e2f362825699d7f6", null ],
    [ "studentNumber", "class_lab3_1_1_student.html#a7701c4b601b61d87fca619c4d2531c56", null ],
    [ "workloadLevel", "class_lab3_1_1_student.html#a00dca19ad2ff836d5159ada1da9877ac", null ],
    [ "AdmissionReason", "class_lab3_1_1_student.html#ae6f6a240f384ff668cc969b931ca1462", null ],
    [ "EducationProgram", "class_lab3_1_1_student.html#a768b0aa09860e31784ac995fb22ebe55", null ],
    [ "Grades", "class_lab3_1_1_student.html#a5c770f15569b9100f2d9c9ec06e85dfb", null ],
    [ "Name", "class_lab3_1_1_student.html#a073e02e88eab780cedd6927525904843", null ],
    [ "Rating", "class_lab3_1_1_student.html#a78c31f1c859b0aebf08091e0454eea16", null ],
    [ "StudentNumber", "class_lab3_1_1_student.html#af54e482310ee6a5541b4fefcf5abc548", null ],
    [ "WorkloadLevel", "class_lab3_1_1_student.html#af3678a23697997bbc49da8f6a22d4575", null ]
];