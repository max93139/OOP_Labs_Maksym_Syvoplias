var class_lab3_1_1_department =
[
    [ "Department", "class_lab3_1_1_department.html#a4ced775bf7afe1ce77c404cb4ea9793a", null ],
    [ "Department", "class_lab3_1_1_department.html#a584c53fb0be242d4e31da5ef079f2d9b", null ],
    [ "AddDiscipline", "class_lab3_1_1_department.html#a7216dfb1a265cdb376838f3465f43bbd", null ],
    [ "AddStudent", "class_lab3_1_1_department.html#a29f12e369af9e0187459cfd921db76fe", null ],
    [ "GetStudentByNumber", "class_lab3_1_1_department.html#ac44e8023a102a84998354e397fee00da", null ],
    [ "RemoveDiscipline", "class_lab3_1_1_department.html#a9f592bb9d9c80b845ec4963fe2cda2b1", null ],
    [ "RemoveStudentByNumber", "class_lab3_1_1_department.html#a84d696737d21c0bdf68877d45dd9d082", null ],
    [ "disciplines", "class_lab3_1_1_department.html#a6f7a3793734c49d07af34f7fcef22fd6", null ],
    [ "educationProgram", "class_lab3_1_1_department.html#a75faf7f2e00b9f293f7f8292a4f6ef16", null ],
    [ "maxStudents", "class_lab3_1_1_department.html#a0f10615203cf074d1318d5c366af7f56", null ],
    [ "name", "class_lab3_1_1_department.html#ac18826cfd79416bb7781f9f5a4500cd0", null ],
    [ "studentCount", "class_lab3_1_1_department.html#a20c7bc5a7da24c3bf28364b157b79384", null ],
    [ "students", "class_lab3_1_1_department.html#a05de6e4b71133436adc1659a67c60548", null ],
    [ "Disciplines", "class_lab3_1_1_department.html#a6dc3614d7f949032abe52ed2b4a7a516", null ],
    [ "EducationProgram", "class_lab3_1_1_department.html#a93aafc5f5e71ce057ae4ba9d73da1b10", null ],
    [ "MaxStudents", "class_lab3_1_1_department.html#ac7b8c4bec265380c43c145c0f06534c1", null ],
    [ "Name", "class_lab3_1_1_department.html#a8ef3d634449357bfe52241868444e9fc", null ],
    [ "StudentCount", "class_lab3_1_1_department.html#abe2febc4b35935e8a690c8de3c60501c", null ],
    [ "Students", "class_lab3_1_1_department.html#adf338da93a7b404b63efe59ce834888e", null ]
];