var files_dup =
[
    [ "obj", "dir_43724e81dd40e09f32417973865cdd64.html", "dir_43724e81dd40e09f32417973865cdd64" ],
    [ "Department.cs", "_department_8cs.html", "_department_8cs" ],
    [ "Program.cs", "_program_8cs.html", "_program_8cs" ],
    [ "Service.cs", "_service_8cs.html", "_service_8cs" ],
    [ "Student.cs", "_student_8cs.html", "_student_8cs" ]
];