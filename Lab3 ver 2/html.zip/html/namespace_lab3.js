var namespace_lab3 =
[
    [ "Department", "class_lab3_1_1_department.html", "class_lab3_1_1_department" ],
    [ "Program", "class_lab3_1_1_program.html", "class_lab3_1_1_program" ],
    [ "Service", "class_lab3_1_1_service.html", "class_lab3_1_1_service" ],
    [ "Student", "class_lab3_1_1_student.html", "class_lab3_1_1_student" ]
];