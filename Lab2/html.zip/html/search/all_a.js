var searchData=
[
  ['totalsum_0',['TotalSum',['../class_console___lab2_1_1_matrix.html#aa79331b44e289a04f7b9ba61a5f91ae7',1,'Console_Lab2::Matrix']]]
];
